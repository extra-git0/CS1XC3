/**
 * @file student.h
 */

/**
 * @struct Student
 * @brief Typedef struct data type for a Student.
 */
typedef struct _student 
{ 
  char first_name[50]; /**< (char[50]) the first name of the student */
  char last_name[50]; /**< (char[50]) the last name of the student */
  char id[11]; /**< (char[11]) the id of the student */
  double *grades; /**< (double*) the pointer to all the grades of the student */
  int num_grades; /**< (int) the number of grades of the student */
} Student;

/**
 * @brief Add grade to the student's file
 * 
 * @param student The pointer to the student to add the grade to.
 * @param grade The grade to add.
 */
void add_grade(Student *student, double grade);

/**
 * @brief Find the student's average grade
 * 
 * @param student The pointer to the student to look through.
 * @return double The average of the student.
 */
double average(Student *student);

/**
 * @brief Prints the student in the terminal
 * 
 * @param student The pointer to the student to print.
 */
void print_student(Student *student);

/**
 * @brief Generates a random student with a set number of grades
 * 
 * @param grades The number of grades to add to the student.
 * @return Student* The pointer to the randomly generated student.
 */
Student* generate_random_student(int grades); 
