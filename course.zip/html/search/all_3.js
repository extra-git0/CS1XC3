var searchData=
[
  ['enroll_5fstudent_0',['enroll_student',['../course_8h.html#af3abbc650ef56ffff427a62dad63fc77',1,'course.c']]]
];
