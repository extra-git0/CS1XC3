var searchData=
[
  ['student_0',['Student',['../struct_student.html',1,'']]],
  ['student_2eh_1',['student.h',['../student_8h.html',1,'']]],
  ['students_2',['students',['../struct__course.html#a5cf448bc80f0f8c5f23402db23d41a00',1,'_course']]]
];
