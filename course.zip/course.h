/**
 * @file course.h
 */

#include "student.h"
#include <stdbool.h>
 
/** 
 * @struct Course
 * @brief Typedef struct data type for a Course.
 */
typedef struct _course 
{
  char name[100]; /**< (char[100]) the name of the course */
  char code[10]; /**< (char[10]) the code of the course */
  Student *students; /**< (Student*) the pointer to all the students in the course */
  int total_students; /**< (int) the number of students in the course */
} Course;

/**
 * @brief Enrolls student in course.
 * 
 * @param course The pointer to the course to enroll the student in.
 * @param student The pointer to the student to enroll.
 */
void enroll_student(Course *course, Student *student);

/**
 * @brief Prints the course to the terminal.
 * 
 * @param course The pointer to the course to print.
 */
void print_course(Course *course);

/**
 * @brief Returns the pointer to the top student in the course.
 * 
 * @param course The pointer to the course to look through.
 * @return Student* The pointer to the top student in the course.
 */
Student *top_student(Course* course);

/**
 * @brief Returns pointers to all passing students in the course, while also setting the total_passing parameter.
 * 
 * @param course The pointer to the course to look through
 * @param total_passing Pointer to int that stores the total number of passing students.
 * @return Student* The pointer to all passing students in the course.
 */
Student *passing(Course* course, int *total_passing);